"""RFsim scene for ParaView: layers, ports, parts and the field. Written by rfsim_viewer.py."""
import json
import os
from paraview.simple import *

# the folder of the data is written into the script: ParaView does not find a script by a relative name
here = "C:/Users/RWache/OneDrive - Rockwell Automation, Inc/Simulation tools/GitHub/ad8317_powermeter/kicad/rfsim_results/run_20261009_230727"
if not os.path.isdir(here):
    here = os.getcwd()
with open(os.path.join(here, "H_field_port1_1GHz_scene.json"), encoding="utf-8") as fh:
    cfg = json.load(fh)
view = GetActiveViewOrCreate("RenderView")
view.OrientationAxesVisibility = 1
view.Background = [0.32, 0.34, 0.43]
view.UseColorPaletteForBackground = 0


def show_poly(name, color, opacity=1.0, line_width=None, points=False):
    reader = XMLPolyDataReader(registrationName=name, FileName=[os.path.join(here, name)])
    display = Show(reader, view)
    display.ColorArrayName = ["POINTS", ""]
    display.DiffuseColor = color
    display.AmbientColor = color
    display.Opacity = opacity
    if line_width:
        display.LineWidth = line_width
    if points:
        display.SetRepresentationType("Points")
        display.PointSize = 12
        display.RenderPointsAsSpheres = 1
    return display


for item in cfg["copper"]:
    show_poly(item["file"], item["color"], 1.0)
if cfg.get("dielectric"):
    show_poly(cfg["dielectric"], [0.35, 0.6, 0.35], 0.18)
if cfg.get("vias"):
    show_poly(cfg["vias"], [0.9, 0.8, 0.2], 1.0, line_width=2)
if cfg.get("ports"):
    show_poly(cfg["ports"], [1.0, 0.9, 0.1], 1.0, line_width=3)
    show_poly(cfg["ports"], [1.0, 0.9, 0.1], 1.0, points=True)
if cfg.get("parts"):
    show_poly(cfg["parts"], [0.1, 0.9, 0.9], 1.0, line_width=6)

for label in cfg["labels"]:
    text = a3DText(registrationName=label["text"], Text=label["text"])
    moved = Transform(Input=text)
    moved.Transform.Scale = [label["size"]] * 3
    moved.Transform.Translate = [label["x"], label["y"], label["z"]]
    display = Show(moved, view)
    display.ColorArrayName = ["POINTS", ""]
    display.DiffuseColor = label["color"]
    display.AmbientColor = label["color"]

if cfg.get("field"):
    field = XMLRectilinearGridReader(registrationName=cfg["field"], FileName=[os.path.join(here, cfg["field"])])
    display = Show(field, view)
    ColorBy(display, ("POINTS", cfg["field_array"]))
    display.RescaleTransferFunctionToDataRange(True, False)
    display.SetScalarBarVisibility(view, True)
    display.Opacity = 0.85

x0, x1, y0, y1 = cfg["bounds"]
view.CameraFocalPoint = [0.5 * (x0 + x1), 0.5 * (y0 + y1), cfg["z_mid"]]
view.CameraPosition = [0.5 * (x0 + x1), 0.5 * (y0 + y1) - 0.01, cfg["z_mid"] + 1.4 * max(x1 - x0, y1 - y0)]
view.CameraViewUp = [0, 1, 0]
Render(view)
