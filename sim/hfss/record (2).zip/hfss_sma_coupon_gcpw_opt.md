# hfss_sma_coupon_gcpw_opt.py — Design Document

## Purpose

`hfss_sma_coupon_gcpw_opt.py` is a parametric HFSS IronPython script for
**iterative optimization of a single SMA-to-GCPW transition**.  It uses a short
(20 mm default) **half-model** with one SMA connector on the left and a matched
GCPW wave port (`WP_MS`) on the right, acting as a Perfect Matched Layer for the
propagating GCPW mode.  This reduces solve time dramatically compared to the
full 60 mm two-connector model in `hfss_sma_coupon_gcpw.py`, making it practical
to run many iterations.

Seven tunable geometry variables target the toammann/Multilayer_SMA2Microstrip
goal of >23 dB return loss DC–20 GHz.

Run from inside AEDT 2026.1: **Tools → Run Script → select this file.**
No external packages required.  Edit the `CONFIG` section before running.

---

## Differences from the Base GCPW Script

| Feature | `hfss_sma_coupon_gcpw.py` | `hfss_sma_coupon_gcpw_opt.py` |
|---|---|---|
| Board length | 60 mm, two SMA connectors | **20 mm**, one SMA connector |
| Right termination | SMA connector + wave port WP2 | **Matched GCPW wave port WP_MS** (acts as PML) |
| F.Cu signal conductor | 1 uniform-width box (`Trace_FCu`) | 5 boxes — entrance + stub + center + stub + entrance |
| Inner-layer planes | Solid full-width copper | In1.Cu and In2.Cu have voids at the **left** board end |
| CONFIG optimization vars | None | 7 variables (see table below) |
| Design name | `SMA_Coupon_GCPW_4L` | `SMA_Coupon_GCPW_Opt_4L` |
| Ports | WP1 (left SMA), WP2 (right SMA) | WP1 (SMA coax), WP_MS (GCPW matched load) |
| Solve time | ~full (two excitations) | **~half** (one connector, shorter domain) |

---

## Coordinate System

```
Z
│  F.Cu (top)
│  ─ ─ ─
│  dielectric
│  ─ ─ ─
│  In1.Cu
│  ─ ─ ─
│  core
│  ─ ─ ─
│  In2.Cu
│  ─ ─ ─
│  dielectric
│  ─ ─ ─
│  B.Cu (bottom)
└────────────────── X (board long axis, connector-to-connector)
```

- **Origin**: centre of the board in XY; z=0 at the bottom of B.Cu.
- **X**: board long axis; board spans `[-hx, +hx]` where `hx = BOARD_LENGTH/2 = 10 mm`.
- **Left end** (x = -hx): SMA connector, wave port `WP1` (coaxial).
- **Right end** (x = +hx): GCPW matched termination wave port `WP_MS` (no physical connector).
- Inner-layer voids are applied only at the **left** board end (where the single connector is).

---

## Optimization Variables

All seven variables live in the `CONFIG` section of the script and can be modified
without changing any other code.

| Variable | Default | Units | Constraint | Effect when increased |
|---|---|---|---|---|
| `COMP_INDUCT_W` | 0.25 | mm | < `TRACE_WIDTH` | Less inductance (closer to main trace width) |
| `COMP_INDUCT_LEN` | 0.40 | mm | < `hx` | More series inductance (longer narrow section) |
| `COMP_CAP_W` | 0.65 | mm | < 2×(htw+gap) | More shunt capacitance (wider stub) |
| `COMP_CAP_LEN` | 0.25 | mm | < `hx - COMP_INDUCT_LEN` | More shunt capacitance (longer stub) |
| `VOID_L2_X` | 4.00 | mm | ≤ `hx` | Larger GND void on In1.Cu → less coupling |
| `VOID_L2_Y` | 2.50 | mm | ≤ `hy` | Wider GND void on In1.Cu |
| `VOID_L3_X` | 3.00 | mm | ≤ `hx` | Larger GND void on In2.Cu |
| `VOID_L3_Y` | 2.00 | mm | ≤ `hy` | Wider GND void on In2.Cu |

**`COMP_CAP_W` hard constraint:**
`COMP_CAP_W / 2` must remain less than `(TRACE_WIDTH/2 + GAP_MM)` so the stub
does not touch the coplanar GND strips.  For the default 4-layer stackup
(TRACE_WIDTH=0.35mm, GAP_MM=0.20mm) the maximum is 0.74mm.  The script
clamps and warns if this is violated.

**Default values** are derived from the Rosenberger 32K242-40ML5 footprint
parameters used in toammann/Multilayer_SMA2Microstrip:
`l01_compL_y=0.25`, `l01_compL_x=0.40`, `l01_compC_y=1.20`, `l01_compC_x=0.25`,
`l03_gnd_ref_cutout=2mm`.  The cap stub width is clamped to fit within the GCPW gap.

---

## F.Cu Signal Conductor Geometry

### Cross-section (XY plane, F.Cu layer, view from above)

```
     -hx                                                        +hx
      │                                                          │
──────┼──────────────────────────────────────────────────────────┼──────  ← +hy
      │         CGND_FCu_PosY (full length)                      │
──────┼──────────────────────────────────────────────────────────┼──────  ← +htw+gap
      │  ←ent→  ←─ cap ─→  ←──────── Trace_FCu_Ctr ──────────→  │  ← right mirror
      │    ╔══╗ ╔══════════╗ ╔═══════════════════════════════╗   │
      │    ║En║ ║   Cap    ║ ║    50-ohm main trace          ║   │  ← +htw
─ Y=0─┼────╠══╬═╬══════════╬═╬═══════════════════════════════╬───┼────────
      │    ║En║ ║   Cap    ║ ║    50-ohm main trace          ║   │  ← -htw
      │    ╚══╝ ╚══════════╝ ╚═══════════════════════════════╝   │
──────┼──────────────────────────────────────────────────────────┼──────  ← -htw-gap
      │         CGND_FCu_NegY (full length)                      │
──────┼──────────────────────────────────────────────────────────┼──────  ← -hy

      ↑                     ↑
      x=-hx              x=-(hx-COMP_INDUCT_LEN-COMP_CAP_LEN)
         ↑               ↑
         x=-(hx-ent)     x=-(hx-ent-cap)
```

### Named objects

| Object | X start | X size | Y centre | Y size | Material |
|---|---|---|---|---|---|
| `Trace_FCu_L_Ent` | -hx | COMP_INDUCT_LEN | 0 | COMP_INDUCT_W | copper |
| `Trace_FCu_L_Cap` | -(hx-COMP_INDUCT_LEN) | COMP_CAP_LEN | 0 | COMP_CAP_W | copper |
| `Trace_FCu_Ctr` | -(hx-ent-cap) | 2×(hx-ent-cap) | 0 | TRACE_WIDTH | copper |
| `Trace_FCu_R_Cap` | +(hx-ent-cap) | COMP_CAP_LEN | 0 | COMP_CAP_W | copper |
| `Trace_FCu_R_Ent` | +(hx-ent) | COMP_INDUCT_LEN | 0 | COMP_INDUCT_W | copper |

*(ent = COMP_INDUCT_LEN, cap = COMP_CAP_LEN)*

All five copper boxes are touching at their faces.  HFSS treats touching
same-material conductors as one electrical body.

### LC network interpretation

```
SMA pin ── [L series: narrow entrance] ── [C shunt: wide stub] ── 50-ohm GCPW
```

The narrower entrance trace has higher characteristic impedance → behaves as
a series inductor.  The wider stub lowers local impedance → behaves as a
shunt capacitor.  Together they form a low-order matching network that
compensates the capacitive discontinuity of the connector body.

---

## Inner-Layer Ground Voids

Inner Cu layers closest to F.Cu receive rectangular voids at each board end
to reduce parasitic capacitive coupling between the connector body and the
inner ground planes (this coupling creates a parallel-plate waveguide mode
that leaks energy at higher frequencies).

### Void geometry (4-layer stackup, half-model)

Voids appear only at the **left** board end (where the SMA connector is).
The right end has no connector — no void needed there.

```
Layer: In1.Cu (user Layer 2, closest to F.Cu)
            VOID_L2_X
          ┣━━━━━━━━━━━┫
   ┌──────┬───────────┬──────────────────────────────────────────────┐
   │      │   void    │                                              │
   │      │  (empty)  │              copper (solid)                  │  ← +VOID_L2_Y
   │      │           │                                              │
   │      │           │              (WP_MS port at right edge)      │
   │      │           │                                              │  ← -VOID_L2_Y
   └──────┴───────────┴──────────────────────────────────────────────┘
   x=-hx             x=-(hx-VOID_L2_X)                          x=+hx
   (SMA)                                                    (GCPW port)

Layer: In2.Cu (user Layer 3) — same pattern with VOID_L3_X / VOID_L3_Y (usually smaller)
Layer: B.Cu — no void (connector body does not reach it on 4-layer board)
```

### Implementation

The full-width copper plane is created first, then the single left-end void
is subtracted with `KeepOriginals=False`:

```
Plane_In1_Cu  ←  subtract(Void_L2_Left)
Plane_In2_Cu  ←  subtract(Void_L3_Left)
```

Note: the script internally still uses `Void_L2_Left` / `Void_L2_Right` naming;
for the half-model only `Void_L2_Left` is created (at the left/SMA end).

For stackups with more than 4 layers, voids are applied to the two inner
layers immediately below F.Cu (always In1.Cu-equivalent and the next one down).

---

## Mesh Strategy

The compensation pieces share `MESH_TRACE_MM` with the main trace but are
registered in a separate mesh operation (`Mesh_Trace_Comp`) so the mesh
assignment is visible independently in the AEDT Mesh Setup tree.

```
Mesh_Transition   → MeshZone_Trans_Left, MeshZone_Trans_Right   [MESH_TRANS_MM]
Mesh_Trace        → Trace_FCu_Ctr                               [MESH_TRACE_MM]
Mesh_Trace_Comp   → L_Ent, L_Cap, R_Cap, R_Ent                 [MESH_TRACE_MM]
Mesh_CoplnarGND   → CGND_FCu_PosY, CGND_FCu_NegY               [MESH_CGND_MM]
Mesh_Planes       → inner + B.Cu planes                         [MESH_PLANE_MM]
Mesh_Vias_xx      → via barrels                                 [MESH_VIA_MM]
Mesh_Skin_xx      → all copper (skin depth)                     [MESH_SKIN_MM]
```

---

## Tuning Workflow

**Primary metric:** `S(WP1,WP1)` = connector return loss — minimize this.
`S(WP_MS,WP1)` = insertion loss into GCPW line — should be near 0 dB at low freq.

After each CONFIG edit: save the `.py` file → AEDT Tools → Run Script → Analyze.
The design is deleted and rebuilt from scratch on each run.

1. **Baseline**: Set all compensation variables to zero-effect values:
   - `COMP_INDUCT_W = TRACE_WIDTH` (entrance = same width as trace)
   - `COMP_CAP_W = TRACE_WIDTH` (stub = same width as trace)
   - `COMP_INDUCT_LEN = 0.01` and `COMP_CAP_LEN = 0.01`
   - `VOID_L2_X = 0.01`, `VOID_L3_X = 0.01`
   Record S(WP1,WP1) — this is the uncompensated transition.

2. **Add voids first**: Increase VOID_L2_X, VOID_L2_Y, VOID_L3_X, VOID_L3_Y.
   Expected: resonant dip in S11 above 10 GHz reduces (less parallel-plate coupling).
   Stop when further increase gives diminishing returns.

3. **Add inductance**: Decrease COMP_INDUCT_W and/or increase COMP_INDUCT_LEN.
   Watch S11 in 1–5 GHz. Too much → rising S11 at low frequency.

4. **Add capacitance**: Increase COMP_CAP_W and/or COMP_CAP_LEN.
   Balances inductance; target flat S11 < -20 dB across 0.1–20 GHz.

5. **Fine-tune**: Iterate inductance ↔ capacitance with voids held fixed.
   Target: S(WP1,WP1) < -23 dB from 0.1 to 20 GHz.

6. **Transfer to full model**: Copy final variable values into `hfss_sma_coupon_gcpw.py`
   (COMP_* and VOID_* variables not present there — add them or apply manually in AEDT)
   and verify with the 60 mm two-connector model before fabrication.

---

## Known AEDT 2026.1 IronPython Constraints

- `Insert3DComponent` ignores `TargetCS` rotation axes (only translates).
  The right connector is corrected via `oEditor.Mirror` about plane x=hx.
  Submodel parts follow the B2 body automatically.

- Mesh refinement boxes that are model solids with `vacuum` material cause
  "Parts intersect" errors.  Use `"Flags:=", "NonModel#"` on these boxes.

- `UseIntLine=False` is required for wave ports in AEDT 2026.1 — explicit
  integration-line endpoints fail the strict boundary check.

- Inner-layer void boxes are created as normal model solids (NOT NonModel).
  They must be subtracted before the HFSS solve validates geometry.
  After subtract, the void bodies are consumed (`KeepOriginals=False`).

- `oEditor.GetMatchedObjectName("*")` does not return 3D-component bodies
  (B1/B2) or their submodel parts.  Use the known body name `"2023R1_HRMG_300_468B2"`
  for the Mirror operation.

---

## Files

| File | Role |
|---|---|
| `sim/hfss/hfss_sma_coupon_gcpw_opt.py` | This script |
| `sim/hfss/hfss_sma_coupon_gcpw.py` | Base GCPW script (unchanged template) |
| `sim/hfss/SM-2400071.a3dcomp` | SMA 3D component (must be in same folder) |

---

## References

- toammann/Multilayer_SMA2Microstrip: Rosenberger 32K242-40ML5 on AISLER 6LayerHD,
  compensation structures `l01_compL_y=0.25`, `l01_compL_x=0.40`,
  `l01_compC_y=1.20`, `l01_compC_x=0.25`, `l03_gnd_ref_cutout=2mm`
- JLCPCB 4-layer stackup: B.Cu / Pre2(0.2101) / In2.Cu / Core1(1.0650) / In1.Cu / Pre1(0.2101) / F.Cu
- See `memory/hfss_pyaedt_board.md` for full IronPython API reference
